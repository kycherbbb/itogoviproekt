console.log("Музыкальная страница загружена");


document.querySelectorAll(".card").forEach(card => {
    card.addEventListener("click", () => {
        alert("Ты выбрал альбом ");
    });
});