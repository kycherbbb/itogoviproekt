const burger = document.getElementById("burger");
const nav = document.getElementById("nav");

if (burger) {
    burger.addEventListener("click", () => {
        nav.classList.toggle("active");
    });
}


document.querySelectorAll(".fact-card").forEach(card => {
    card.addEventListener("click", () => {
        alert("Факт выбран ");
    });

    card.addEventListener("mouseenter", () => {
        card.style.boxShadow = "0 0 15px ";
    });

    card.addEventListener("mouseleave", () => {
        card.style.boxShadow = "none";
    });
});

window.addEventListener("scroll", () => {
    const header = document.querySelector(".header");
    if (window.scrollY > 50) {
        header.style.background = "#111";
    } else {
        header.style.background = "#000";
    }
});